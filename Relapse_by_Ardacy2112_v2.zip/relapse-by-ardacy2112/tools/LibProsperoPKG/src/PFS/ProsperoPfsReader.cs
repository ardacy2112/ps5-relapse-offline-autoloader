// LibProsperoPkg - A library for building and inspecting PS5 packages.
// Copyright (C) 2026 SvenGDK
//
// PFS image structures, builder and reader primitives.
#nullable disable
using LibProsperoPkg.Util;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;

namespace LibProsperoPkg.PFS;

/// <summary>
/// Class allowing parallel readonly access to a PFS archive
/// </summary>
public class ProsperoPfsReader
{
    /// <summary>
    /// Represents a file or directory in a PFS image.
    /// </summary>
    public abstract class Node
    {
        public Dir parent;
        public string name;
        public long offset;
        public long size;
        public long compressed_size;
        public uint ino;
        public string FullName => parent != null ? parent.FullName + "/" + name : name;
    }
    /// <summary>
    /// Represents a directory in a PFS image.
    /// </summary>
    public class Dir : Node
    {
        public List<Node> children = new List<Node>();
        public Node Get(string name)
          => children.Where(x => x.name == name).FirstOrDefault();
        public Node GetPath(string name)
        {
            var breadcrumbs = name.Split('/');
            Node n = this;
            var bc = 0;
            while (n != null && bc < breadcrumbs.Length)
            {
                n = (n as Dir)?.Get(breadcrumbs[bc]);
                bc++;
            }
            if (bc < breadcrumbs.Length)
            {
                return null;
            }
            return n;
        }
        public IEnumerable<File> GetAllFiles()
        {
            foreach (var n in children)
            {
                if (n is File f) yield return f;
                if (n is Dir d)
                    foreach (var x in d.GetAllFiles())
                        yield return x;
            }
        }
    }
    /// <summary>
    /// Represents a file in a PFS image.
    /// </summary>
    public class File : Node
    {
        public ProsperoInodeFlags flags;
        public int blockSize;
        public int[] blocks;
        private IMemoryReader reader;
        public File(IMemoryReader r) { reader = r; }
        public IMemoryReader GetView()
        {
            if (blocks != null)
                return new ChunkedMemoryReader(reader, blockSize, blocks);
            return new MemoryAccessor(reader, offset);
        }
        public void Save(string path, bool decompress = false)
        {
            var buf = new byte[blockSize];
            using (var file = System.IO.File.OpenWrite(path))
            {
                var sz = size;
                file.SetLength(sz);
                long pos = 0;
                var reader = GetView();
                // Only PFSC-decode when the payload is actually a PFSC container. The outer-PFS inode
                // template carries the `compressed` flag even on raw files (e.g. nwonly's
                // naps_pkg_layout.dat, which is stored raw), so the flag alone is not a reliable signal;
                // wrapping a raw payload in ProsperoPfscReader would throw "missing PFSC magic".
                if (decompress && flags.HasFlag(ProsperoInodeFlags.compressed) && size >= 4)
                {
                    var magic = new byte[4];
                    reader.Read(0, magic, 0, 4);
                    if (magic[0] == (byte)'P' && magic[1] == (byte)'F' && magic[2] == (byte)'S' && magic[3] == (byte)'C')
                    {
                        sz = compressed_size;
                        reader = new ProsperoPfscReader(reader);
                    }
                }
                while (sz > 0)
                {
                    var toRead = (int)Math.Min(sz, buf.Length);
                    reader.Read(pos, buf, 0, toRead);
                    file.Write(buf, 0, toRead);
                    pos += toRead;
                    sz -= toRead;
                }
            }
        }
    }

    // Private state for the PfsReader class
    private IMemoryReader reader;
    private ProsperoPfsHeader hdr;
    private ProsperoInode[] dinodes;
    private Dir root;
    private Dir uroot;
    private byte[] sectorBuf;
    private Stream sectorStream;

    public ProsperoPfsReader(MemoryMappedViewAccessor r, ulong pfs_flags = 0, byte[] ekpfs = null, byte[] tweak = null, byte[] data = null)
    : this(new MemoryMappedViewAccessor_(r), pfs_flags, ekpfs, tweak, data)
    { }
    /// <param name="r">Backing memory reader over the PFS image.</param>
    /// <param name="pfs_flags">Superblock pfs_flags selecting the crypto scheme (e.g. the newCrypt bit).</param>
    /// <param name="ekpfs">Image key used to derive the per-image XTS keys, or null for a plaintext image.</param>
    /// <param name="tweak">Explicit XTS tweak key, or null to derive it from <paramref name="ekpfs"/>.</param>
    /// <param name="data">Explicit XTS data key, or null to derive it from <paramref name="ekpfs"/>.</param>
    /// <param name="superblockByteOffset">Byte offset of the superblock within the image. 0 for a normal
    /// superblock-first PFS; for a PS5 "data-first" outer PFS the superblock sits near the end (block D), so the
    /// caller passes D*blockSize. Block pointers stay absolute from the image base (offset 0); only the superblock
    /// and the dinode table (block D+1) are located relative to this offset.</param>
    /// <param name="skipDecryption">When true, the image is already plaintext (e.g. a data-first outer PFS the
    /// caller decrypted up-front with the per-block plain/signed XTS scheme), so the reader must NOT re-apply its
    /// linear XTS even though the superblock's mode still carries the Encrypted flag.</param>
    public ProsperoPfsReader(IMemoryReader r, ulong pfs_flags = 0, byte[] ekpfs = null, byte[] tweak = null, byte[] data = null,
        long superblockByteOffset = 0, bool skipDecryption = false)
    {
        reader = r;
        var buf = new byte[0x400];
        reader.Read(superblockByteOffset, buf, 0, 0x400);

        using (var ms = new MemoryStream(buf))
        {
            hdr = ProsperoPfsHeader.ReadFromStream(ms);
        }
        int dinodeSize;
        Func<Stream, ProsperoInode> dinodeReader;
        bool is64 = hdr.Mode.HasFlag(ProsperoPfsMode.Is64Bit);
        if (hdr.Mode.HasFlag(ProsperoPfsMode.Signed))
        {
            // PS5 signed images use 64-bit block pointers in their inodes.
            if (is64)
            {
                dinodes = new ProsperoDinodeS64[hdr.DinodeCount];
                dinodeReader = ProsperoDinodeS64.ReadFromStream;
                dinodeSize = (int)ProsperoDinodeS64.SizeOf; // 0x310
            }
            else
            {
                dinodes = new ProsperoDinodeS32[hdr.DinodeCount];
                dinodeReader = ProsperoDinodeS32.ReadFromStream;
                dinodeSize = (int)ProsperoDinodeS32.SizeOf; // 0x2C8
            }
        }
        else
        {
            dinodes = new ProsperoDinodeD32[hdr.DinodeCount];
            dinodeReader = ProsperoDinodeD32.ReadFromStream;
            dinodeSize = (int)ProsperoDinodeD32.SizeOf; // 0xA8
        }
        if (!skipDecryption && hdr.Mode.HasFlag(ProsperoPfsMode.Encrypted))
        {
            const int XtsSectorSize = 0x1000;
            uint XtsStartSector = hdr.BlockSize / XtsSectorSize;
            if (ekpfs == null && (tweak == null || data == null))
                throw new ArgumentException("PFS image is encrypted but no decryption key was provided");
            if (ekpfs != null)
            {
                var (tweakKey, dataKey) = Crypto.PfsGenEncKey(ekpfs, hdr.Seed, (pfs_flags & 0x2000000000000000UL) != 0);
                reader = new ProsperoXtsDecryptReader(reader, dataKey, tweakKey, XtsStartSector, XtsSectorSize);
            }
            else
            {
                reader = new ProsperoXtsDecryptReader(reader, data, tweak, XtsStartSector, XtsSectorSize);
            }
        }
        var total = 0;

        var maxPerSector = hdr.BlockSize / dinodeSize;
        sectorBuf = new byte[hdr.BlockSize];
        sectorStream = new MemoryStream(sectorBuf);
        // skip over indirect blocks, block signatures are never checked anyway. For a data-first outer PFS the
        // superblock is at superblockByteOffset (block D) and its dinode table follows at block D+1.
        var dinodeStartPos = superblockByteOffset + hdr.BlockSize + (hdr.BlockSize * hdr.InodeBlockSig.IndirectBlocks.Where(b => b > 0).Count());
        for (var i = 0; i < hdr.DinodeBlockCount; i++)
        {
            var position = dinodeStartPos + (hdr.BlockSize * i);
            reader.Read(position, sectorBuf, 0, sectorBuf.Length);
            sectorStream.Position = 0;
            for (var j = 0; j < maxPerSector && total < hdr.DinodeCount; j++)
                dinodes[total++] = dinodeReader(sectorStream);
        }
        root = LoadDir(0, null, "");
        uroot = root.Get("uroot") as Dir;
        if (uroot == null)
            throw new Exception("Invalid PFS image (no uroot)");
        uroot.name = "uroot";
    }

    public ProsperoPfsHeader Header => hdr;

    public File GetFile(string fullPath)
    {
        return uroot.GetPath(fullPath) as File;
    }

    public IEnumerable<File> GetAllFiles()
    {
        return uroot.GetAllFiles();
    }

    public Dir GetURoot()
    {
        return uroot;
    }

    public Dir GetSuperRoot()
    {
        return root;
    }

    private Dir LoadDir(uint dinode, Dir parent, string name)
    {
        // 100M blocks is enough for a 6TB file.
        const int MAX_BLOCKS = 100_000_000;
        var ret = new Dir() { name = name, parent = parent };
        var ino = dinodes[dinode];
        var postLoad = new List<Func<Dir>>();
        var blocks = (int)ino.Blocks;
        if (blocks < 1 || ino.StartBlock < 1 || ino.StartBlock > MAX_BLOCKS || blocks > MAX_BLOCKS)
        {
            throw new Exception($"Inode {dinode} is corrupt. ");
        }
        foreach (var x in Enumerable.Range(ino.StartBlock, blocks))
        {
            var position = hdr.BlockSize * x;
            reader.Read(position, sectorBuf, 0, sectorBuf.Length);
            sectorStream.Position = 0;
            while (position < hdr.BlockSize * (x + 1))
            {
                var dirent = ProsperoPfsDirent.ReadFromStream(sectorStream);
                if (dirent.EntSize == 0) break;
                switch (dirent.Type)
                {
                    case ProsperoDirentType.File:
                        ret.children.Add(LoadFile(dirent.InodeNumber, ret, dirent.Name));
                        break;
                    case ProsperoDirentType.Directory:
                        postLoad.Add(() => LoadDir(dirent.InodeNumber, ret, dirent.Name));
                        break;
                    case ProsperoDirentType.Dot:
                        break;
                    case ProsperoDirentType.DotDot:
                        break;
                    default:
                        break;
                }
                position += dirent.EntSize;
            }
        }
        foreach (var p in postLoad)
        {
            ret.children.Add(p());
        }
        return ret;
    }

    private File LoadFile(uint dinode, Dir parent, string name)
    {
        int[] blocks = null;
        if (dinodes[dinode].Blocks > 1 && dinodes[dinode].DirectBlocks[1] != -1)
        {
            if (!hdr.Mode.HasFlag(ProsperoPfsMode.Signed))
            {
                throw new Exception("Unsigned PFS images probably shouldn't have noncontiguous blocks");
            }
            blocks = new int[dinodes[dinode].Blocks];
            var remainingBlocks = (long)dinodes[dinode].Blocks;
            var sigsPerBlock = hdr.BlockSize / 36;
            for (int i = 0; i < 12 && i < remainingBlocks; i++)
            {
                blocks[i] = dinodes[dinode].DirectBlocks[i];
            }

            var bufferedReader = new BufferedMemoryReader(reader, 0x10000);
            remainingBlocks -= 12;
            long blockIndexOffset = 12;
            for (int i = 0; i < remainingBlocks && i < sigsPerBlock; i++)
            {
                bufferedReader.Read(dinodes[dinode].IndirectBlocks[0] * hdr.BlockSize + (i * 36) + 32, out blocks[i + blockIndexOffset]);
            }
            remainingBlocks -= sigsPerBlock;
            blockIndexOffset += sigsPerBlock;
            for (int j = 0; j * sigsPerBlock < remainingBlocks; j++)
            {
                bufferedReader.Read(dinodes[dinode].IndirectBlocks[1] * hdr.BlockSize + (j * 36) + 32, out int indirectBlockOffset);
                for (int i = 0; i < sigsPerBlock && i + (j * sigsPerBlock) < remainingBlocks; i++)
                {
                    bufferedReader.Read(indirectBlockOffset * hdr.BlockSize + (i * 36) + 32, out blocks[i + blockIndexOffset]);
                }
                blockIndexOffset += sigsPerBlock;
            }
            bool contiguous = true;
            for (int i = 1; i < blocks.Length; i++)
            {
                if (blocks[i - 1] + 1 != blocks[i])
                {
                    contiguous = false;
                    break;
                }
            }
            if (contiguous)
                blocks = null;
        }
        return new File(reader)
        {
            name = name,
            parent = parent,
            offset = dinodes[dinode].StartBlock * hdr.BlockSize,
            size = dinodes[dinode].Size,
            compressed_size = dinodes[dinode].SizeCompressed,
            ino = dinode,
            blocks = blocks,
            flags = dinodes[dinode].Flags,
            blockSize = (int)hdr.BlockSize
        };
    }
}
